import React from "react";
function TopperBlue() {
    return ( 
        <>
          
        <div class="student-card bg-light-blue">
                    <div class="detail">
                        <h4 class="text-blue">95.8%</h4>
                        <p class="name">Nayan Kumar</p>
                        <p class="rank">All India Topper - CBSE 2021</p>
                    </div>

                    <img src="../assets/imgs/student2.png" alt="topper"/>
                </div>
        </>
     );
}

export default TopperBlue;